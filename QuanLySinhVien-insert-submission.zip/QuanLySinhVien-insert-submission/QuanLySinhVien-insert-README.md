# QuanLySinhVien — Thực hành INSERT INTO

## Nội dung

Script `QuanLySinhVien-insert.sql` thêm dữ liệu mẫu vào bốn bảng:

- `Class`: A1, A2 và B3.
- `Student`: Hung, Hoa và Manh.
- `Subject`: CF, C, HDJ và RDBMS.
- `Mark`: ba bản ghi điểm theo đề bài.

## Thứ tự chèn dữ liệu

Dữ liệu được chèn theo thứ tự `Class`, `Student`, `Subject`, `Mark` để các khóa ngoại luôn hợp lệ. Bản ghi của Hoa không có số điện thoại nên cột `Phone` được truyền giá trị `NULL`.

Script có phần xóa dữ liệu cũ trước khi chèn để có thể chạy lại trong môi trường thực hành. Không nên chạy phần `DELETE` trên cơ sở dữ liệu có dữ liệu thật.

## Cách chạy

```bash
mysql -u root -p < QuanLySinhVien-insert.sql
```

Cuối script có các lệnh `SELECT` để kiểm tra từng bảng và một truy vấn `JOIN` tổng hợp sinh viên, lớp, môn học và điểm.
