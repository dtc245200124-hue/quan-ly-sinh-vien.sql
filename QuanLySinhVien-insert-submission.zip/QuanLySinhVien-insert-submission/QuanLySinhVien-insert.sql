-- =========================================================
-- Bài thực hành: Thêm dữ liệu vào CSDL quản lý sinh viên
-- CSDL: QuanLySinhVien
-- =========================================================

USE QuanLySinhVien;

-- Xóa dữ liệu theo thứ tự phụ thuộc để script có thể chạy lại.
DELETE FROM Mark;
DELETE FROM Student;
DELETE FROM Subject;
DELETE FROM Class;

-- Đặt lại bộ đếm AUTO_INCREMENT sau khi xóa dữ liệu.
ALTER TABLE Class AUTO_INCREMENT = 1;
ALTER TABLE Student AUTO_INCREMENT = 1;
ALTER TABLE Subject AUTO_INCREMENT = 1;
ALTER TABLE Mark AUTO_INCREMENT = 1;

-- 1. Thêm dữ liệu bảng Class.
INSERT INTO Class (ClassID, ClassName, StartDate, Status)
VALUES
    (1, 'A1', '2008-12-20', 1),
    (2, 'A2', '2008-12-22', 1),
    (3, 'B3', CURRENT_DATE, 0);

-- 2. Thêm dữ liệu bảng Student.
-- StudentID tự tăng nên không cần truyền vào.
INSERT INTO Student
    (StudentName, Address, Phone, Status, ClassID)
VALUES
    ('Hung', 'Ha Noi', '0912113113', 1, 1),
    ('Hoa', 'Hai Phong', NULL, 1, 1),
    ('Manh', 'HCM', '0123123123', 0, 2);

-- 3. Thêm dữ liệu bảng Subject.
INSERT INTO Subject (SubID, SubName, Credit, Status)
VALUES
    (1, 'CF', 5, 1),
    (2, 'C', 6, 1),
    (3, 'HDJ', 5, 1),
    (4, 'RDBMS', 10, 1);

-- 4. Thêm dữ liệu bảng Mark.
INSERT INTO Mark (SubID, StudentID, Mark, ExamTimes)
VALUES
    (1, 1, 8, 1),
    (1, 2, 10, 2),
    (2, 1, 12, 1);

-- 5. Kiểm tra dữ liệu đã chèn.
SELECT * FROM Class;
SELECT * FROM Student;
SELECT * FROM Subject;
SELECT * FROM Mark;

-- 6. Truy vấn tổng hợp để kiểm tra quan hệ giữa sinh viên, lớp và môn học.
SELECT
    s.StudentID,
    s.StudentName,
    c.ClassName,
    sub.SubName,
    m.Mark,
    m.ExamTimes
FROM Mark m
JOIN Student s ON s.StudentID = m.StudentID
JOIN Class c ON c.ClassID = s.ClassID
JOIN Subject sub ON sub.SubID = m.SubID
ORDER BY s.StudentID, sub.SubID;
